# Katana
Sistema de Tienda en Linea

Características

- Gestión de productos, precios, etc
- Vista de productos destacados, por categoría y búsqueda
- Vista individual de un producto
- Registro de clientes
- Visualización de compras
- Agregar productos al carrito de compras
- Procesamiento del carrito de compras
- Impresión en PDF de la nota de compra
- Modulo de ventas
- Marcar ventas como pendientes, pagadas, en camino, entregadas y canceladas.
- Gestion de categorias
- Organización de productos por categorías
- Controla los usuarios que tendran acceso al sistema de administración
- Mucho mas

Link: http://evilnapsis.com/2015/10/16/katana-lite-sistema-de-tienda-en-linea/