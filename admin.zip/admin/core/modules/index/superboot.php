<?php
session_start();
// superboot.php
// 14 octubre del 2014
// El codigo siguiente se ejecuta en todas los views y action

// echo "Hello superboot";


?>